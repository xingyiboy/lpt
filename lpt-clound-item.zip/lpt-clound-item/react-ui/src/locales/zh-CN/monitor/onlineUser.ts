
/* *
 *
 * @author whiteshader@163.com
 * @datetime  2021/09/16
 * 
 * */

export default {
  'monitor.online.user.id': '编号',
  'monitor.online.user.token_id': '会话编号',
  'monitor.online.user.user_name': '会话编号',
  'monitor.online.user.ipaddr': '登录IP地址',
  'monitor.online.user.login_location': '登录地点',
  'monitor.online.user.browser': '浏览器类型',
  'monitor.online.user.os': '操作系统',
  'monitor.online.user.dept_name': '部门',
  'monitor.online.user.login_time': '访问时间',
  'monitor.online.user.force_logout': '强制退出',
};
