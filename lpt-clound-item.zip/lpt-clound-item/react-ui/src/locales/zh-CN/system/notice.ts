export default {
	'system.notice.title': '通知公告',
	'system.notice.notice_id': '公告编号',
	'system.notice.notice_title': '公告标题',
	'system.notice.notice_type': '公告类型',
	'system.notice.notice_content': '公告内容',
	'system.notice.status': '公告状态',
	'system.notice.create_by': '创建者',
	'system.notice.create_time': '创建时间',
	'system.notice.update_by': '更新者',
	'system.notice.update_time': '更新时间',
	'system.notice.remark': '备注',
};
