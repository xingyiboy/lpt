export default {
	'system.post.title': '岗位信息',
	'system.post.post_id': '岗位编号',
	'system.post.post_code': '岗位编码',
	'system.post.post_name': '岗位名称',
	'system.post.post_sort': '显示顺序',
	'system.post.status': '状态',
	'system.post.create_by': '创建者',
	'system.post.create_time': '创建时间',
	'system.post.update_by': '更新者',
	'system.post.update_time': '更新时间',
	'system.post.remark': '备注',
};
