/* eslint-disable */
// 该文件由 OneAPI 自动生成，请勿手动修改！

import * as Auth from './auth';
import * as User from './User';
import * as Dict from './dict';
import * as Menu from './menu';

export default {
  Auth,
  User,
  Dict,
  Menu,
};
