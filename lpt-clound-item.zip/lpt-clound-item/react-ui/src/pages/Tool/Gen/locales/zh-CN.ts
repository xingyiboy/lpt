export default {
  'gen.import': '导入',
  'gen.title': '表信息',
  'gen.goback': '返回',
  'gen.submit': '提交',
  'gen.gencode': '生成',
  'gen.preview': '预览',
};
