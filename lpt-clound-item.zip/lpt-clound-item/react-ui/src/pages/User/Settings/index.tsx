import { PageContainer } from '@ant-design/pro-components';
import { Card } from 'antd';
import React from 'react';

/**
 *
 * @author whiteshader@163.com
 *
 * */


const Settings: React.FC = () => {
  return (
    <PageContainer>
      <Card title="Developing" />
    </PageContainer>
  );
};

export default Settings;
