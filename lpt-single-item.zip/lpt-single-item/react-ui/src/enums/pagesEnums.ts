
export enum PageEnum {
    LOGIN = '/user/login'
}