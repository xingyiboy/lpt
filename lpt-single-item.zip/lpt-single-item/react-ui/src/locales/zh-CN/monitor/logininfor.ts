export default {
	'monitor.logininfor.title': '系统访问记录',
	'monitor.logininfor.info_id': '访问编号',
	'monitor.logininfor.user_name': '用户账号',
	'monitor.logininfor.ipaddr': '登录IP地址',
	'monitor.logininfor.login_location': '登录地点',
	'monitor.logininfor.browser': '浏览器类型',
	'monitor.logininfor.os': '操作系统',
	'monitor.logininfor.status': '登录状态',
	'monitor.logininfor.msg': '提示消息',
	'monitor.logininfor.login_time': '访问时间',
	'monitor.logininfor.unlock': '解锁',
};
