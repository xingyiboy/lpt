export default {
	'system.config.title': '参数配置',
	'system.config.config_id': '参数主键',
	'system.config.config_name': '参数名称',
	'system.config.config_key': '参数键名',
	'system.config.config_value': '参数键值',
	'system.config.config_type': '系统内置',
	'system.config.create_by': '创建者',
	'system.config.create_time': '创建时间',
	'system.config.update_by': '更新者',
	'system.config.update_time': '更新时间',
	'system.config.remark': '备注',
	'system.config.refreshCache': '刷新缓存',
};
