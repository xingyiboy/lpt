export default {
  'system.dict.title': '字典类型',
  'system.dict.dict_id': '字典主键',
  'system.dict.dict_name': '字典名称',
  'system.dict.dict_type': '字典类型',
  'system.dict.status': '状态',
  'system.dict.create_by': '创建者',
  'system.dict.create_time': '创建时间',
  'system.dict.update_by': '更新者',
  'system.dict.update_time': '更新时间',
  'system.dict.remark': '备注',
};
